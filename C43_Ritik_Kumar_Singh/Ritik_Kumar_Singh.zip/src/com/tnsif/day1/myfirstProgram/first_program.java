package com.tnsif.day1.myfirstProgram;

public class first_program {
	public static void main(String[] args) {
		System.out.println("hello king");
	}

}
