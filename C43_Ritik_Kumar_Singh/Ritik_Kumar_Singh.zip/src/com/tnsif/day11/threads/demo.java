package com.tnsif.day11.threads;

public class demo {
	public static void main(String[] args) {
		System.out.println("the program continues....");
		int data=100/0;
	}
	
}
