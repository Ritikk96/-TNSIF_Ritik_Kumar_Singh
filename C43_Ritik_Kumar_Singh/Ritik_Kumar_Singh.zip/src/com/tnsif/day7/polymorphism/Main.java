package com.tnsif.day7.polymorphism;

public class Main {
	
	int   add(int a  , int b , int c) {
		c = a + b;
		System.out.println(c);
		
	}
	int add(int a   , int  b , int c)
	
	
	
	public static void main(String[] args) {
		
	
		
	}
}
